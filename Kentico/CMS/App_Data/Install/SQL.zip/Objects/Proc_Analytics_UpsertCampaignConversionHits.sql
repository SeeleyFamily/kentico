SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[Proc_Analytics_UpsertCampaignConversionHits]
	@CampaignID int,
	@HitsToUpsertTable Type_Analytics_CampaignConversionHitsTable readonly
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
		WITH ConversionHits AS (	
						SELECT * 
						FROM Analytics_CampaignConversionHits 
						WHERE CampaignConversionHitsConversionID 
								IN (SELECT CampaignConversionID 
								FROM Analytics_CampaignConversion
								WHERE CampaignConversionCampaignID = @CampaignID))
	 MERGE ConversionHits AS target
		USING @HitsToUpsertTable AS source 
	 ON target.CampaignConversionHitsConversionID = source.CampaignConversionID 
		AND target.CampaignConversionHitsSourceName = source.ActivityUTMSource
		AND (ISNULL(target.CampaignConversionHitsContentName, '') = ISNULL(source.ActivityUTMContent, ''))
	 WHEN MATCHED THEN
		UPDATE SET CampaignConversionHitsCount = target.CampaignConversionHitsCount + source.Hits
	 WHEN NOT MATCHED THEN
		INSERT (CampaignConversionHitsConversionID, CampaignConversionHitsSourceName, CampaignConversionHitsContentName, CampaignConversionHitsCount)
		VALUES (source.CampaignConversionID, source.ActivityUTMSource, source.ActivityUTMContent, source.Hits);
END
GO
