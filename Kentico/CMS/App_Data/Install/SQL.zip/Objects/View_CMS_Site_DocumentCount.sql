SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [View_CMS_Site_DocumentCount] AS
SELECT	SiteID, SiteName, SiteDisplayName, SiteDescription, SiteStatus, SiteDomainName,
	SiteDefaultVisitorCulture, SiteGUID, SiteLastModified, SitePresentationUrl,
	(SELECT	COUNT(*) AS Documents
		FROM CMS_Tree
		WHERE (NodeSiteID = CMS_Site.SiteID)) AS Documents
FROM CMS_Site
GO
