SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Proc_OM_Account_MassDelete]
@where nvarchar(max),
	@deleteSubsidiaries bit
AS
BEGIN
SET NOCOUNT ON;

  -- Variables
	DECLARE @DeletedAccounts TABLE (
		AccountID int NOT NULL
	);
	DECLARE @SubsidiaryAccounts TABLE (
		AccountID int NOT NULL
	);
	DECLARE @currentDeletedAccountID int;
	DECLARE @currentSubsidiaryAccountID int;
	DECLARE @sqlQuery NVARCHAR(MAX);

	-- Get TOP 1000 of deleted accounts
	SET @sqlQuery = 'SELECT TOP 1000 AccountID FROM OM_Account WHERE ' + @where;
	INSERT INTO @DeletedAccounts EXEC(@sqlQuery);

	-- Process first batch of records
	WHILE ((SELECT Count(*) FROM @DeletedAccounts) > 0)
	BEGIN
  	WHILE ((SELECT Count(*) FROM @DeletedAccounts) > 0)
	  BEGIN			
		  SELECT TOP 1 @currentDeletedAccountID = AccountID FROM @DeletedAccounts;
    
      IF @deleteSubsidiaries > 0
      BEGIN
		    INSERT INTO @SubsidiaryAccounts SELECT AccountID FROM OM_Account WHERE AccountSubsidiaryOfID = @currentDeletedAccountID;
					
		    WHILE ((SELECT Count(*) FROM @SubsidiaryAccounts) > 0)
		    BEGIN		
			    SELECT TOP 1 @currentSubsidiaryAccountID = AccountID FROM @SubsidiaryAccounts;
													
			    -- Remove contacts from contact groups which are added via the account
			    SET @where = 'AccountID = ' + CAST(@currentSubsidiaryAccountID AS nvarchar(50));
			    EXEC Proc_OM_ContactGroupMember_RemoveContactsFromAccount @where
							
			    /* Remove all references */
          UPDATE OM_Account SET AccountSubsidiaryOfID = NULL WHERE AccountSubsidiaryOfID =  @currentSubsidiaryAccountID;
                            
          /* Remove all relations */
          DELETE FROM OM_AccountContact WHERE AccountID = @currentSubsidiaryAccountID;
          DELETE FROM OM_ContactGroupMember WHERE ContactGroupMemberType=1 AND ContactGroupMemberRelatedID = @currentSubsidiaryAccountID;

			    -- Delete record
			    DELETE FROM OM_Account WHERE AccountID = @currentSubsidiaryAccountID;
			    DELETE FROM @SubsidiaryAccounts WHERE AccountID = @currentSubsidiaryAccountID;
		    END
      END

      -- Remove contacts from contact groups which are added via the account
      SET @where = 'AccountID = ' + CAST(@currentDeletedAccountID AS nvarchar(50));
      EXEC Proc_OM_ContactGroupMember_RemoveContactsFromAccount @where
                
      /* Remove all references */
      UPDATE OM_Account SET AccountSubsidiaryOfID = NULL WHERE AccountSubsidiaryOfID =  @currentDeletedAccountID;
                
      /* Remove all relations */
      DELETE FROM OM_AccountContact WHERE AccountID = @currentDeletedAccountID;
      DELETE FROM OM_ContactGroupMember WHERE ContactGroupMemberType=1 AND ContactGroupMemberRelatedID = @currentDeletedAccountID;
				
      -- Delete record
      DELETE FROM OM_Account WHERE AccountID = @currentDeletedAccountID;
			
      DELETE FROM @DeletedAccounts WHERE AccountID = @currentDeletedAccountID;

      -- Get next batch of a
      INSERT INTO @DeletedAccounts EXEC(@sqlQuery);
    END
  END
END
GO
